package com.seip.android.todoappb1.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.seip.android.todoappb1.databinding.FragmentCreateTotoBinding;
import com.seip.android.todoappb1.pickers.DatePikerDialogFragment;
import com.seip.android.todoappb1.pickers.TimePikerDialogFragment;
import com.seip.android.todoappb1.utils.TodoConstants;

public class CreateTotoFragment extends Fragment {

    FragmentCreateTotoBinding binding;

    private String dateString, timeString;
    private int year, month, day, hour, minute;
    private String priority = TodoConstants.NORMAL;

    public CreateTotoFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCreateTotoBinding.inflate(inflater, container, false);



        binding.dateBV.setOnClickListener(v -> {
            new DatePikerDialogFragment().show(getChildFragmentManager(), null);
        });

        binding.timeBV.setOnClickListener(v -> {
            new TimePikerDialogFragment().show(getChildFragmentManager(), null);
        });

        binding.saveBV.setOnClickListener(v -> {

        });

        getChildFragmentManager().setFragmentResultListener(TodoConstants.REQUEST_KEY, this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                if (result.containsKey(TodoConstants.DATE_KEY)){
                    dateString = result.getString(TodoConstants.DATE_KEY);
                    year = result.getInt(TodoConstants.YEAR);
                    month = result.getInt(TodoConstants.MONTH);
                    day = result.getInt(TodoConstants.DAY);
                    binding.dateBV.setText(dateString);
                }else if(result.containsKey(TodoConstants.TIME_KEY)){
                    timeString = result.getString(TodoConstants.TIME_KEY);
                    hour = result.getInt(TodoConstants.HOUR);
                    minute = result.getInt(TodoConstants.MINUTE);
                    binding.timeBV.setText(timeString);
                }
            }
        });


        return binding.getRoot();
    }
}